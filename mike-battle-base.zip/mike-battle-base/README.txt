MIKE BATTLE BASE

Para publicar en Netlify:
1. Entra a https://app.netlify.com/drop
2. Sube la carpeta completa o el archivo ZIP.
3. Netlify te dará un enlace para abrir el juego en Safari.

Archivo principal: index.html
